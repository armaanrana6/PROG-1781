﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A2ArmaanRanaP2
{
    class Program
    {
        static double volume(double r)
        {
            double sphere;
            sphere = 4 * 3.14 / 3 * r * r * r;
            return sphere;
        }
        static double volume(double r, double h)
        {
            double cylinder;
            cylinder = 3.14 * r * r * h;
            return cylinder;
        }
        static double volume(int l, int b, int h)
        {
            double prism;
            prism = l * b * h;
            return prism;
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Select the type of Shape to find volume");
            Console.WriteLine("1:Sphere");
            Console.WriteLine("2:Cylinder");
            Console.WriteLine("3:Rectangular Prism");
            string x = Console.ReadLine();
            int y = int.Parse(x);
            if (y == 1)
            {
                Console.WriteLine("enter the value of radius");
                string u = Console.ReadLine();
                double r = double.Parse(u);
                double result;
                result = volume(r);
                Console.WriteLine("Volume of sphere = " + result);
            }
            else if (y == 2)
            {
                Console.WriteLine("enter the value of radius");
                string i = Console.ReadLine();
                double r = double.Parse(i);
                Console.WriteLine("enter the value of height");
                string k = Console.ReadLine();
                double h = double.Parse(i);
                double res;
                res = volume(r, h);
                Console.WriteLine("Volume of cylinder =" + res);
            }
            else if (y == 3)
            {
                Console.WriteLine("enter the length of rectangle");
                string a = Console.ReadLine();
                int l = int.Parse(a);
                Console.WriteLine("enter the breadth of rectangle");
                string c = Console.ReadLine();
                int b = int.Parse(c);
                Console.WriteLine("enter the height of rectangle");
                string d = Console.ReadLine();
                int h = int.Parse(d);
                double resu;
                resu = volume(l, b, h);
                Console.WriteLine("Volume of rectangular prism is " + resu);
            }
        }
    }
}
    