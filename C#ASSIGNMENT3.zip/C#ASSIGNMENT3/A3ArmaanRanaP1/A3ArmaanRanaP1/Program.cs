﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A3ArmaanRanaP1
{
    class Program
    {
        static void Main(string[] args)
        {
            do
            {
                try
                {
                    Console.WriteLine("Select an option");
                    Console.WriteLine("1.Display a list of even numbers starting at 0");
                    Console.WriteLine("2.Display a sequence of perfect squares");
                    Console.WriteLine("3.Exit");
                    double choice = double.Parse(Console.ReadLine());



                    if (choice == 1)
                    {
                        Console.WriteLine("enter number of even numbers to display");
                        double even = double.Parse(Console.ReadLine());

                        for (int e = 2; e <= 2 * even; e = e + 2)
                        {

                            Console.WriteLine(e);


                        }
                    }


                    if (choice == 2)
                    {
                        Console.WriteLine("1");
                        int i = 0;
                        do
                        {
                            
                            Console.WriteLine("Select: 1.Continue, 2.Stop");
                            int a = (i + 1) * (i + 1);
                            Console.WriteLine(a);
                            i = i + 1;
                        }


                        while (Console.ReadLine() == "1");
                    }


                }
                catch (FormatException z)
                {
                    Console.WriteLine("Enter valid value");

                }
                finally
                {

                    Console.WriteLine("----------");

                }

            } while (true);
        }
    }
}

    