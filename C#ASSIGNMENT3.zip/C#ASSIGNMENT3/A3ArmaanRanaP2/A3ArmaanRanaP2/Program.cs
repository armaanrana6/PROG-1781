﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A3ArmaanRanaP2
{
    class Program
    {
        static void Main(string[] args)
        {
            double infinity = 1;
            do {
                try
                {
                    double result = 0;

                    Console.WriteLine("Type yourfirst number :");
                    double firstNumber = double.Parse(Console.ReadLine());
                    

                    Console.WriteLine("Type your second number :");
                    double secondNumber = double.Parse(Console.ReadLine());
                    

                    Console.WriteLine("Select the operation + (plus) , - (minus) , * (multiply) , / (divide), :");
                    char operation = char.Parse(Console.ReadLine());

                    switch (operation)
                    {
                        case '+':
                            result = firstNumber + secondNumber;
                            
                            break;

                        case '-':
                            result = firstNumber - secondNumber;
                            
                            break;

                        case '*':
                            result = firstNumber * secondNumber;
                           
                            break;

                        case '/':
                            result = firstNumber / secondNumber;
                            break;
                        default:
                            Console.WriteLine("Error!");
                            break;


                    }
      
                    Console.WriteLine("Output: " +firstNumber+ " " +operation+ " " +secondNumber+ " =  " +result);


                }
                catch (ArithmeticException e)
                {
                    Console.WriteLine("Error!");
                }
                catch (FormatException e)
                {
                    Console.WriteLine("Invalid value");
                }

                finally
                {
                    Console.WriteLine("");
                }
            }
            while ( infinity==1);

        }
    }
}
